# 🧹 Source Hygiene — Moon Source component

**Agent Skill:** [Download Source Hygiene skill (.zip)](https://github.com/luahelenammc/Moon-Source/raw/refs/heads/main/downloads/skills/moon-source-hygiene.zip) · [All public skills](https://github.com/luahelenammc/Moon-Source/tree/main/downloads/skills)


A public source-hygiene method for auditing context corpora, project files and knowledge systems whose problem is deeper than retrieval.

> Better retrieval cannot repair a source that is itself stale, contradictory, duplicated or governed by the wrong authority.

**Project MRI** is the lineage name for this family of work. Its standalone executable reference implementation is published at [Project MRI](https://github.com/luahelenammc/Project-MRI). This document publishes a bounded diagnostic interface, not a finished autonomous scanner or the private MRI engine.

Broken intellectual custody is a source-hygiene finding. Missing origin, unclear authorship, lost canonical identity, unrecorded transformations, permission drift, derivative ambiguity or unattributed material reuse can all make a corpus structurally unreliable even when retrieval works. Use [Credits & Attribution Ops](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CREDITS_ATTRIBUTION_OPS.md) for the dedicated protection operation; do not publish private custody ledgers or infer legal permission from a missing marker.

**MSL profile:** 5.1-compatible Markdown-native method surface; preserve source authority, freshness and custody boundaries.

## 🔍 What kind of failure is this?

| Finding | The question |
|---|---|
| **Retrieval failure** | Can the needed material be found and loaded? |
| **Source-architecture failure** | Is the corpus itself organized around the right responsibilities and authorities? |
| **Stale authority** | Does an old or superseded source still look current? |
| **Duplication** | Do several files repeat the same responsibility without a clear owner? |
| **Contradiction** | Do sources disagree without a resolved jurisdiction? |
| **Orphaned decision** | Does a decision exist without a visible owner, source or next consequence? |
| **Bloat / fossilization** | Is historical or low-value material increasing cognitive load or silently governing the present? |
| **Jurisdiction drift** | Has a copy, bridge, archive or public surface started acting like the authority? |
| **Freshness failure** | Is there no visible update trigger, review point or current-state marker? |
| **Broken intellectual custody** | Can a reader recover the material's origin, authorship, canonical identity, transformation history and relevant lineage? |

The distinction matters because a better index, search layer or retrieval prompt cannot repair contradictory source architecture or a broken chain of intellectual custody.

## 🧭 Public diagnostic loop

Use the smallest loop that can explain the problem:

1. **Inventory** the files, sources, objects, owners and surfaces involved.
2. **Identify current authority** for each important claim, state or decision.
3. **Map freshness**: current, dated, superseded, unknown or review-triggered.
4. **Detect structural findings**: contradiction, duplication, stale authority, orphan state, bloat, jurisdiction drift or broken intellectual custody.
5. **Classify severity without fake scoring**: explain the consequence instead of manufacturing a universal number.
6. **Propose conservative repairs**: relabel, link, split, merge, demote, archive, restore canonical identity, repair lineage or create a bounded bridge.
7. **Preserve history and provenance** so the repair does not erase how the state changed.
8. **Require explicit mutation authority** before rewriting governed sources.

A diagnosis can conclude that no mutation is warranted. “No change” is a valid repair when the evidence is insufficient or the risk of rewriting is higher than the gain.

## Relationship to Source Operations

[Source Operations](https://github.com/luahelenammc/Moon-Source/blob/main/docs/SOURCE_OPERATIONS.md) owns the operation chosen after a hygiene finding is confirmed: retrieve, process, metabolize or promote. It also defines the smallest sovereign destination, readback, no_delta_with_reason, lifecycle and legacy-successor rules.

Source Hygiene remains the diagnostic owner. A scan may conclude that the source already contains the needed function, that evidence is insufficient, or that no mutation is warranted. In those cases, preserve the finding without cosmetic rewriting and use the appropriate no-delta or incubation disposition.

## Runtime correction versus persistent mutation

A runtime correction changes the active frame used for the present task when evidence exposes a material source, jurisdiction, variant, version, ontology, authority or runtime-surface mismatch. It is not, by itself, a persistent mutation.

Source Reflex owns that bounded correction and persistence classification. Source Hygiene remains the owner of stale, contradictory, duplicated or bloated corpus diagnosis. After a correction, route any writeback through the smallest sovereign destination, explicit mutation authority, privacy and provenance checks, and readback. A valid outcome may be no delta.

## 🧪 Proportional output

A useful finding should be recorded with:

| Field | What to capture |
|---|---|
| **Finding** | The observed hygiene problem |
| **Evidence** | The exact source, passage, path, timestamp or relationship supporting it |
| **Governing source** | The current authority, or UNKNOWN when unresolved |
| **Risk** | What could go wrong if the finding remains |
| **Smallest repair** | The least invasive action that improves legibility |
| **Mutation authority** | Who or what must authorize a rewrite |
| **Lineage impact** | What history, archive, mirror, canonical identity or derivative relationship must be preserved |
| **Custody impact** | Which authorship, transformation, permission or disclosure facts must remain recoverable |
| **Uncertainty** | What remains unproven |

## 🛠️ Apply it now

Copy this bounded worksheet into an AI conversation:

~~~
Run a Moon Source source-hygiene scan on the corpus below.

Corpus / file map:
[paste the file list, excerpts, links, or object descriptions]

For each material finding, return:
- finding;
- evidence;
- current governing source;
- freshness status;
- contradiction / duplication / orphan / bloat / jurisdiction / intellectual-custody signal;
- risk;
- smallest conservative repair;
- mutation authority required;
- archive, lineage, custody or mirror impact;
- uncertainty.

Then return:
1. the most important unresolved authority question;
2. any source that should be demoted to mirror, archive or reference;
3. any missing canonical, lineage or custody marker;
4. what should remain unchanged because evidence is insufficient;
5. the next review or freshness trigger.

Do not invent scores, hidden taxonomies, private case data or autonomous repair.
Do not rewrite a governed source without explicit mutation authority.
~~~

## 📏 Claim ceiling

This is a public source-hygiene method and bounded Project MRI lineage surface. It does not establish a finished scanner, autonomous repair, hidden taxonomy, scoring system, private evaluation corpus, external adoption or measured impact.

See [Architecture](https://github.com/luahelenammc/Moon-Source/blob/main/ARCHITECTURE.md), [Evidence and Claims](../EVIDENCE_AND_CLAIMS.md) and [Public Boundary](../PUBLIC_BOUNDARY.md).

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
