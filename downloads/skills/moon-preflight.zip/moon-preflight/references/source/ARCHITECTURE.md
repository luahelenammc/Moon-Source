# 🏗️ Architecture — Field to Form — Moon Source architecture

Moon Source is a way to decide what kind of context a human, team, project or institution actually needs before forcing the material into a fixed container.

Its public thesis is:

> Moon Source begins with the field, not the container.

The field may be a person, a project, an institution, a workflow, a body of knowledge, a relationship between systems, or a changing combination of these. The work is to understand that field, locate authority and responsibility, and choose the smallest materialization that can carry the work safely.

## The public topology

```
field / reality
      ↓
observation and diagnosis
      ↓
jurisdiction and authority
      ↓
topology and responsibility map
      ↓
proportional materialization
      ↓
operation and transport
      ↓
feedback, hygiene, lineage, custody and archive
      ↺
```

This is a decision topology, not a universal mandatory lifecycle. A materialization can reveal new facts and send the work back to observation, authority or topology.

## Where Moon Source sits in an AI stack

Moon Source is easiest to locate by responsibility rather than by treating the AI ecosystem as a fixed product taxonomy:

| Responsibility | Typical question | Moon Source relationship |
|---|---|---|
| Model cognition and generation | What reasoning or generation can be produced from the active context? | The model consumes governed context and produces an output; it does not decide source jurisdiction by itself. |
| Agent harness / runtime | How does an agent loop, use tools, maintain execution state and act? | A harness may execute procedures and actions. Moon Source can govern the context boundaries around that work, but does not provide the runtime. |
| Retrieval / memory mechanisms, including RAG | What external material should be retrieved or assembled for this inference? | Retrieval supplies access or assembly. Moon Source adds responsibility for authority, freshness, permission, scope and provenance around that material. |
| Governed context / source architecture | Which source is allowed to govern, how current is it, what may travel or mutate, and what must remain attributable across time and surfaces? | This is Moon Source's primary responsibility, including the boundaries where context is loaded, transported, changed and verified. |

In compact form:

```text
RAG asks:         what external material should be retrieved for this inference?
Harness asks:     how does the agent loop, use tools, maintain state and act?
Moon Source asks: what may govern, how current is it, what may travel or mutate,
                  and what must remain attributable across time and surfaces?
```

These are responsibility-oriented comparisons, not a universal ontology. A harness or retrieval system may implement some governance of its own; Moon Source complements those mechanisms rather than replacing them. It is not an agent harness, RAG engine, orchestration framework, runtime or SDK.

**Conversational products are also a context field.** Application state obtained from APIs, database queries, spreadsheets or event systems can govern what a user-facing assistant may say or remember between exchanges. Documents are only one context substrate. The subordinate [Conversational Context integration contract](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONVERSATIONAL_CONTEXT.md) illustrates purpose, permissions, dialogue state, trusted operational state, human escalation and synthetic acceptance tests without creating another Moon Source capability. Jurisdiction-specific constraints require operator-approved [requirements profiles](https://github.com/luahelenammc/Moon-Source/blob/main/docs/JURISDICTIONAL_REQUIREMENTS.md), not model-invented legal decisions.

## Relationship to Moon Cortex

[Moon Cortex](https://github.com/luahelenammc/Moon-Cortex) is the related public applied/system body for domain-shaped modules. Moon Source governs context, authority, provenance, freshness, transport and reconfiguration; Cortex owns domain-specific module identity and operation.

The relationship is complementary and asymmetric: a Cortex module may consult Moon Source for installation/context governance, but Cortex is not a Moon Source capability and Moon Source is not a permanent runtime dependency. User-local state remains under the user's or authorized local system's sovereignty.

## One capability, multiple roles

Moon Source keeps one canonical semantic body for each public capability. The
architectural role says what the capability is; an optional standalone
distribution says how that body can travel. A distribution is never a second
method authority:

```text
one public capability
→ one canonical semantic body
→ one architectural responsibility
→ zero or more distribution, mirror, package and adapter roles
```

A capability may be structurally central and independently portable at the same
time, including a crown-jewel capability. A mirror or ZIP package carries the
body for delivery. A distinct adapter is allowed only when it owns volatile or
surface-specific implementation facts that should not become stable doctrine.
History belongs to Git; it does not require an active compatibility twin.

## Before the topology: Preflight

Before asking what structure the field deserves, the AI may need to solve a more human problem: **what is the person actually trying to accomplish?**

[Preflight](portables/preflight/PREFLIGHT.md) is the human-intent reconstruction layer before execution. Its current public version is **2.4**. It is AI-led self-prompt engineering at the task level: the model reads human expression as a whole, distinguishes request from context, example, hesitation and correction, then builds a faithful working prompt before execution. It asks only when consequential ambiguity remains.

Its core loop is intentionally simpler than the architectural topology:

```text
human expression
→ intended meaning
→ desired outcome
→ preserve / change / avoid
→ faithful working task
→ execute
```

When the reconstructed task materially involves governed sources, fresh external facts, sensitive/public consequences or state-changing execution, Preflight activates the relevant authority, provenance, freshness, risk, destination, mutation and readback guardrails or routes to the capability that owns them.

This ordering matters. **Preflight first understands the human; architecture enters when the work earns architecture.**

Preflight can therefore:

- terminate quickly and let a clear request execute directly;
- resolve conversational ambiguity without forcing the user to rewrite themselves as a prompt;
- route into the [Field-to-Form diagnostic](#field-to-form) when the reconstructed need is genuinely architectural;
- route into a specialized public capability when the consequence, not the wording, requires authority, freshness, provenance, safety or execution safeguards;
- reroute when the user corrects the meaning or new evidence changes the field.

It is transversal, not a mandatory permanent stage in the topology. **Preflight reconstructs the task; Field to Form decides what the field deserves to become.**

<a id="field-to-form"></a>
## Field-to-Form diagnostic

Field to Form is the practical diagnostic inside the canonical Moon Source architecture. Use it when the field is real but its durable form, ownership or operating boundary is still unresolved. It moves through **field → observation → diagnosis → jurisdiction → topology → materialization → operation → hygiene, lineage and custody**. The loop may return to an earlier decision when new evidence changes the field.

### Choose the public entry point

- **Human-intent reconstruction before execution:** start with [🛫 Preflight](portables/preflight/PREFLIGHT.md) when the request is conversational, incomplete, self-correcting, ambiguous or likely to be misunderstood if followed literally. Consequence-triggered execution guardrails remain available when the resulting task is risky, public, source-governed or mutable.
- **Personal or project context:** start with [🧭 Setup](portables/setup/MOON_SOURCE_SETUP.md), which routes depth and form from the user's actual need.
- **Project, team or knowledge field:** run this Field-to-Form diagnostic before choosing a document type.
- **Structure, source, handoff or protocol design:** use [🧱 Moon Source Language](portables/msl/MOON_SOURCE_LANGUAGE.md) after the responsibility is clear.
- **Execution routing and orchestration:** use the [🧬 Adaptive Orchestration Protocol](https://github.com/luahelenammc/Moon-Source/blob/main/portables/adaptive-orchestration/README.md) when the control root, execution surface, model, reasoning effort or delegation topology must be chosen; the protocol governs those decisions while the harness performs the execution.
- **Intellectual lineage and immaterial-asset protection:** use [🧾 Credits & Attribution Ops](docs/CREDITS_ATTRIBUTION_OPS.md) when intellectual material must retain identity, authorship, canonicality, transformation history, permission scope, disclosure boundaries, derivative lineage and recoverable evidence as it moves or changes.
- **Licensing and redistribution:** use [LICENSING](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) to route software to Apache-2.0, documentation and public capability distributions to CC-BY-4.0, and third-party material to its own terms.
- **Reusable procedure:** use [🧩 Procedural Projection](https://github.com/luahelenammc/Moon-Source/blob/main/docs/PROCEDURAL_PROJECTION.md) when a stable method needs triggers, boundaries, output and QA.
- **Concrete recurring execution:** use [🛠️ Operational Devices](https://github.com/luahelenammc/Moon-Source/blob/main/docs/OPERATIONAL_DEVICES.md) when a procedure needs a named surface, state, guards and receipts; use [🛡️ Operational Reliability](docs/OPERATIONAL_RELIABILITY.md) to keep that execution diagnosable and bounded.
- **Recurring or costly failure:** use [🏭 Failure to Capability — Failure Foundry](https://github.com/luahelenammc/Moon-Source/blob/main/docs/FAILURE_FOUNDRY.md) when a failure pattern may have earned a smaller reusable rule, gate, procedure or device.
- **Ambiguous or convergent signals:** use [🎚️ Signal Calibration](docs/SIGNAL_CALIBRATION.md) when weak or incomplete cues need a useful working inference without being promoted to fact or discarded through caveats.
- **Stale or contradictory corpus:** use [🧹 Source Hygiene](docs/SOURCE_HYGIENE.md) when retrieval is not the real problem.
- **Connected source operation:** use the canonical [🔗 Connected Sources capability](docs/CONNECTED_SOURCES.md) when an AI must reach persistent external memory or resolve authority, freshness, retrieval scope and mutation boundaries through a connector. Load the dated [ChatGPT adapter notes](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONNECTED_SOURCES_CHATGPT_ADAPTER.md) only when current product behavior materially matters.

### Run it

Copy the operation below into an AI conversation or use it as a worksheet:

```text
Use the Moon Source public Field-to-Form architecture on the situation below.

Return only what is needed to choose a proportionate form:
- Field as it exists before choosing a document type
- Observed pressures, friction, relevant sources and actors
- Authority / jurisdiction for each important claim or state
- Responsibilities, owners and relationships that must remain distinct
- Candidate materializations
- Smallest adequate form, with the reason it earns existence
- What is intentionally not being created
- Operation / transport
- Freshness or update trigger
- Active state, lineage, custody or archive boundary
- Next action

Keep facts, inference and uncertainty distinct where that distinction could change the choice.
Do not require every Moon Source artifact family. The form comes from the field.

Situation:
[describe or attach the material]
```

### Practical test

Before creating a new artifact, ask:

- What capability would exist after this artifact exists?
- Which source, role or responsibility becomes clearer?
- Who will use it?
- What is its freshness contract?
- What is its authority?
- What is explicitly outside its scope?
- What evidence can support its public claims?
- What intellectual identity, lineage, canonical path, permission or disclosure boundary must remain recoverable if the material travels or changes?
- What is the smallest form that can carry the answer?

If the answer is only “the project will look more complete,” the artifact probably does not deserve to exist yet.

An operational device earns existence only when a simple procedure, protocol, handoff or checklist does not adequately carry the recurring execution. Its surface, trigger, state, limits, failure behavior, receipts and recovery path must be inspectable. A device is not generated by default and does not become a source of authority merely because it can be invoked.

For supporting decisions, use the [Responsibility Map](docs/RESPONSIBILITY_MAP.md) and [🧱 Moon Source Language](portables/msl/MOON_SOURCE_LANGUAGE.md).

**Download the full public Moon Source:** [complete repository (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip). For individual files and standalone distributions, use the [download hub](https://github.com/luahelenammc/Moon-Source/blob/main/DOWNLOADS.md).

## 1. Field

The field is the situation before it has been reduced to a document type.

Questions include:

- What is happening in practice?
- Who is involved, affected or responsible?
- Which sources, memories, routines and constraints are already present?
- What is changing?
- What would fail if the context were misunderstood?
- Who needs to use the resulting structure?

A field can be personal, organizational, technical, creative, public or mixed. The first responsibility is to see which pressures are actually present.

## 2. Observation and diagnosis

Observation turns a vague field into an inspectable situation. It can include weak or ambiguous cues as long as they remain labeled as cues. Diagnosis distinguishes signal from accumulation and may form a working inference when relevant cues converge, provided observation, inference, alternatives, uncertainty and authority remain visible.

Typical observations concern:

- current and historical sources;
- recurring decisions and unresolved questions;
- workflows, handoffs and friction;
- role boundaries and hidden dependencies;
- freshness, duplication and contradiction;
- privacy, safety and exposure;
- evidence available for each important claim.

Diagnosis does not automatically produce a solution. It determines which kind of solution would be proportionate.

Use [Signal Calibration](docs/SIGNAL_CALIBRATION.md) when the field supports a useful interpretation but not an established claim. Uncertainty should calibrate the confidence of the interpretation; it should not automatically suppress the interpretation. This does not establish motive, diagnosis, causality or a public claim.

## 3. Jurisdiction and authority

Different sources can be valid without having the same job.

Source jurisdiction asks:

- Which source governs this claim or state?
- Which source is only an echo, projection, bridge or snapshot?
- What is current?
- What is historical?
- Who is allowed to change it?
- What must remain outside the public or operational surface?

The architecture describes context responsibilities and interfaces; it does not claim a scoring feature without a documented implementation.

### Connected sources and persistent substrate

A living-source architecture expected to survive sessions needs a persistent source substrate accessible to the AI. The substrate may be a document corpus, repository or equivalent surface; the vendor is not the ontology. Use the canonical [Connected Sources](docs/CONNECTED_SOURCES.md) body to distinguish reach from authority, source/data authority from instruction authority, targeted retrieval from exhaustive inventory, write capability from mutation authority and write receipts from accepted source state.

For the ChatGPT reference implementation, Google Drive is the primary document-source substrate for durable living sources. GitHub is complementary and becomes governing when executable or repository state is part of the question. This is a facet-scoped implementation pattern, not a compulsory linear stage or universal Drive-plus-GitHub stack. Product-specific details belong in the subordinate [ChatGPT adapter notes](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONNECTED_SOURCES_CHATGPT_ADAPTER.md).

## 4. Topology and responsibility map

Before selecting a format, map the entities and their relationships.

A useful map separates:

- sources and their owners;
- projects and their boundaries;
- procedures and their triggers;
- tasks and their deadlines or recurrence;
- public and private surfaces;
- active state and archive;
- bridges between systems;
- people or roles accountable for decisions.

The point is not to create a grand ontology. The point is to avoid asking one object to perform several incompatible jobs.

## 5. Choose a proportional materialization

A field may need one materialization or several. Common choices include:

- a living source for governed, updateable context;
- a skill for a reusable procedure;
- a handoff for transfer between people, models, threads or projects;
- a packet or capsule for bounded transport;
- a protocol for repeatable operating rules;
- a registry or ledger for identity, decisions, versions or checkpoints;
- a bridge for translation across systems;
- a public surface for human access;
- an archive for history that should not govern the present.

The materialization earns its existence by changing what the field can support. A new file that only repeats another file is not an architectural improvement.

Not every explanation needs a new artifact or workflow. When the immediate need is **understanding in conversation**, a visually composed answer can be the smallest materialization: a didactic diagram, comparison, short illustrated flow, icon/color-guided grouping or labeled chart. Choose the form for explanatory value before considering interactive widgets, a dashboard, HTML source or a separate application. See [Conversation-native Visual Explanation](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONVERSATION_NATIVE_VISUAL_EXPLANATION.md) for the subordinate design guidance; do not promote it into a new architecture stage or capability.

When one capability needs both structural responsibility and independent transport, keep one canonical semantic body and describe transport as a distribution role. Canonical placement follows architectural responsibility; standalone distribution neither creates a second registry identity nor requires a semantic twin.

## 6. Operation and transport

A materialization becomes useful when it can travel without losing its purpose, authority, limits or provenance.

Transport may involve:

- a supported standalone distribution;
- a handoff with current state and next actions;
- a packet with explicit scope and exclusions;
- a bridge that translates without transferring semantic authority;
- a workflow or runtime that performs a bounded operation.

Transport is not the same as authority. A copy can carry context while the source of truth remains elsewhere.

[Source Operations](docs/SOURCE_OPERATIONS.md) defines the public operation grammar for this layer: retrieve finds governing context; process transforms the working representation without default writeback; metabolize integrates an eligible delta into the current owner; promote generalizes a mature mechanism across jurisdictions. These are distinct operations, not a mandatory pipeline.

When a reusable procedure needs concrete execution, keep the relationship explicit:

```text
procedure → operational device → concrete surface / runtime → action + receipt
```

The device embodies the procedure on a bounded surface; it does not become a source of authority, gain new privilege or prove that documentation alone is a runtime. A surface-specific adapter binds the generic device to the surface and carries its freshness and fragility assumptions.

## 7. Feedback, hygiene, lineage, custody and archive

For a bounded public operation, use [Source Hygiene](docs/SOURCE_HYGIENE.md) to distinguish retrieval problems from source-architecture problems. Use [Procedural Projection](https://github.com/luahelenammc/Moon-Source/blob/main/docs/PROCEDURAL_PROJECTION.md) when feedback shows that a recurring method deserves a reusable procedure. Use [Credits & Attribution Ops](docs/CREDITS_ATTRIBUTION_OPS.md) when intellectual material needs a recoverable chain of custody across origin, authorship, canonical identity, transformation, permission, exposure, derivatives and evidence.

A living architecture must account for change.

The source governs; the ledger witnesses. The governing body answers what is current now; a history, checkpoint, changelog or ledger preserves how the state changed without becoming current policy merely because it is newer. Use [Source Operations](docs/SOURCE_OPERATIONS.md) for the mutation, lifecycle and legacy-successor contract that keeps this distinction operational.

Feedback includes:

- what changed;
- which previous assertion was superseded;
- what remains uncertain;
- what needs review;
- what belongs in active state;
- what should be preserved as lineage;
- which authorship, canonical identity, transformation history, permission scope and disclosure boundary must remain recoverable;
- which descendants should remain connected to an upstream lineage;
- what should be archived or retired.

History matters, but history should not quietly govern the present. Active sources should remain legible; archives should preserve the past without impersonating current truth. Likewise, material that travels through copies, adaptations, models or public surfaces should not lose its identity merely because its container changed.

## MSL as grammar

Moon Source Language, or MSL, is the structural grammar used by the Moon Source work. MSL 5.1 makes semantic passage explicit while remaining adaptive and Markdown-native. It helps choose form from field pressure while preserving source authority, continuity, provenance, proportionality and active-state hygiene.

MSL is not the whole architecture. It does not replace source jurisdiction, procedural skills, domain methods, bridges, runtime capacity or public-boundary judgment.

## What this architecture is not

Moon Source is not:

- a prompt pack;
- a single knowledge-base template;
- an agent harness, RAG engine, orchestration framework, runtime or SDK;
- a universal ontology;
- a claim of external adoption;
- a claim that more context is always better;
- a guarantee that a standalone distribution includes every integration or implementation detail.

## Claim ceiling

This repository is a public reference architecture and a versioned home for public capabilities and their supported distributions. It does not by itself prove impact, adoption, product-market fit, universal validity or enterprise readiness.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
