# 🔄 Source Operations — Moon Source component

**Agent Skill:** [Download Source Operations skill (.zip)](https://github.com/luahelenammc/Moon-Source/raw/refs/heads/main/downloads/skills/moon-source-operations.zip) · [All public skills](https://github.com/luahelenammc/Moon-Source/tree/main/downloads/skills)


Source Operations is the public Moon Source method surface for deciding how governed context is found, interpreted, changed, preserved and deliberately generalized across jurisdictions.

Its central distinction is:

> Retrieve finds what governs. Process changes the working representation. Metabolize integrates an eligible delta into the source that owns it. Promote generalizes a proven mechanism without importing its private habitat.

This document defines an operation family, not a second AI Kernel. The AI Kernel routes into it; Connected Sources governs connector reach and source access; Source Hygiene diagnoses corpus failure; Archive and Legacy preserves superseded history; Credits & Attribution Ops preserves material lineage and custody.

**MSL profile:** 5.1-compatible Markdown-native method surface; preserve source authority, lifecycle and readback boundaries.

## Scope and boundary

Source Operations applies to public, project, organizational or other governed source work when the operation itself matters: loading context, analyzing material, integrating a real change, or considering a mature mechanism for a broader layer.

It is:

- a public method for source operations and lifecycle;
- a contract for mutation, readback, no-delta and smallest sovereign destination;
- a promotion gate that keeps novelty separate from generalization;
- a reusable succession pattern for superseded artifacts;
- a bounded way to distinguish active state, history, lineage, archive and incubation.

It is not:

- an autonomous migration, promotion, archive or reconciliation engine;
- permission to mutate a source merely because it is reachable;
- a universal taxonomy, score or product claim;
- a copy of any private or local source;
- a replacement for domain-specific authority, licensing, privacy or safety review.

The method is portable because the function survives changes of vendor, connector, repository, document format or private vocabulary.

Connected Sources answers whether and how a source can be reached, refreshed or safely written through an available substrate. Source Operations answers what to do with the reached material: retrieve, process, metabolize or promote. A source locator or connector capability never grants mutation authority, instruction authority or ownership of the destination.

## 1. The operation family

| Operation | Governing question | Default effect |
|---|---|---|
| Retrieve | Which current source or jurisdiction governs this task? | Read and compile a bounded working set; no mutation |
| Process | What does the material mean, change or imply for the task? | Transform the working representation; no writeback by default |
| Metabolize | What eligible delta belongs in the current governing source? | Integrate the smallest sovereign mutation, then read back |
| Promote | Does a mature mechanism deserve a broader jurisdiction? | Abstract, sanitize, lineage-link and choose a promotion disposition |

These operations are related, but they are not a compulsory chain. A retrieve may be enough. A process may end in a proposal or no delta. A metabolized change may remain in its current jurisdiction. A promoted mechanism may be rejected, incubated or already public.

## Source Reflex

Source Reflex is the bounded correction loop used when active execution reveals a material mismatch between the frame being used and the source, jurisdiction, artifact variant, version, ontology, authority or runtime surface that should govern the task.

> Correct the active map before deciding whether the source needs a patch.

During an active task, frame correction may be reflexive when evidence is sufficient. This is execution-local correction, not autonomous maintenance: no background scan, silent rewrite, automatic publication or mutation authority inferred from access.

### Trigger boundary

Use Source Reflex when execution finds:

- a governing source or effective authority different from the one presumed;
- an artifact jurisdiction, variant or version that does not fit the task;
- a snapshot, bridge or copy treated as canonical;
- an ontology or runtime surface that does not match the source meant to govern;
- an explicit correction or a conflict between current sources.

Do not activate it for cosmetic preference, equivalent wording, immaterial noise or a new external fact when the current frame remains correct. External material enters through Nectar and reaches Source Reflex only when it evidences a frame mismatch.

### Canonical receipt

Every material correction should leave a compact receipt with:

- trigger, mismatch type, evidence and confidence;
- active frame before and corrected frame;
- governing source, smallest sovereign destination and mutation authority;
- persistence class, local action, upstream candidacy and next operator;
- readback and residual uncertainty.

The source/jurisdiction preflight route should expose **jurisdiction_fit: pass | corrected | conflict**, the corrected source/frame, mismatch type, confidence, persistence relevance and next operator. Living State Reconciliation may consume this receipt after jurisdiction is resolved; it does not resolve jurisdiction on behalf of preflight.

### Persistence and authority

- **instance_only:** correct the working frame for the present task only.
- **source_gap_local:** preserve a reusable local gap without implying an upstream change.
- **source_conflict:** preserve competing authorities and do not force a synthesis.
- **upstream_candidate:** abstract, sanitize and de-duplicate a reusable pattern; candidacy is not promotion.

The authority ladder remains bounded: A0 observes; A1 corrects and classifies; A2 writes locally only under explicit authority; A3 prepares or promotes publicly only under explicit public instruction or a delegated workflow, with review, gate and readback. Correction and candidacy do not grant mutation authority.

### Public-surface writing guard

When a reusable mechanism is prepared for a public surface, carry the mechanism itself, the dependencies and claim limits needed to use it, and only the attribution needed for credit, licensing, public lineage or correct reuse. General repository authorship and licensing belong in the canonical credit, licensing and stamp surfaces; do not add a per-component `Provenance and attribution`, donor-history or production-history section merely to narrate how the public artifact was produced. Provenance remains in a component when provenance is part of the component's actual method or data model. Omit private source maps, source numbers, production diaries and synchronization narration that do not serve a public-use requirement.

### Composition boundary

Project MRI remains responsible for broad system-health and drift inspection. Source Mutation Hygiene Gate controls write safety. Source Operations owns retrieve, process, metabolize, promote, lifecycle and no-delta decisions. Nectar owns external material, credit and provenance. Living State Reconciliation reconciles state after source and authority are resolved. Source Reflex routes among these owners; it is not a new content owner or a new standalone capability.

### Synthetic acceptance cases

- **A — variant mismatch:** the task names a V1 artifact while the current governing body is V2; correct the active variant, continue, and keep the correction instance-only unless a separate gap is proven.
- **B — stale snapshot:** a snapshot disagrees with the current source; current source governs, while the snapshot remains evidence rather than canonical state.
- **C — bridge treated as canonical:** a bridge packet is mistaken for the source of truth; route back to the sovereign source and do not rewrite the bridge as if it owned the content.
- **D — reusable local gap:** a correction exposes a repeatable local behavior without public proof; classify source_gap_local and route to the smallest local destination.
- **E — upstream candidate:** a sanitized, non-duplicative pattern is reusable beyond the local habitat; classify upstream_candidate, prepare the public packet, and stop at the promotion gate.
- **F — ambiguous conflict:** two current authorities remain materially incompatible; preserve source_conflict, surface the uncertainty and request the next decision.
- **G — no delta:** the current frame remains correct after inspection; record no_delta and make no mutation.

### Retrieve

Retrieve locates and loads governing context for the present task.

A sound retrieve:

1. identifies the relevant source, jurisdiction, facet or authority;
2. loads current material at the smallest useful scope;
3. preserves provenance or freshness when they affect the decision;
4. keeps unresolved absence unresolved instead of inventing state;
5. returns a working baseline, not a new source.

Retrieve is read-only by default. Search, connector access and a retrieved passage are evidence of reach, not automatic authority.

### Process

Process interprets, parses, compares, transforms or synthesizes material for the current task.

It may:

- extract structure, meaning, deltas or alternatives;
- compare a candidate with the current state;
- produce an analysis, synthesis, draft, patch candidate or decision;
- identify uncertainty, contradiction or a need for another source.

Process changes the working representation, not the source by default. It does not silently persist because the material feels important. An explicit later mutation command or binding may authorize the next operation.

### Metabolize

Metabolize integrates an eligible delta into the governing source within the current jurisdiction.

The operation must:

1. resolve the governing destination;
2. read enough current state to detect duplication, contradiction or supersession;
3. identify the smallest real behavioral, factual, routing, risk, state or claim delta;
4. reject cosmetic repetition and stale destinations;
5. patch the smallest sovereign destination;
6. preserve material provenance and lineage;
7. read back the mutated source;
8. return no_delta_with_reason when no eligible change exists.

A successful write is not yet source acceptance. The mutation becomes accepted only after the changed source is reread and the intended current state is coherent.

### Promote

Promote deliberately moves a mature, reusable mechanism toward a broader jurisdiction.

Promotion means:

1. locate the donor authority;
2. retrieve its current semantics and evidence;
3. process and isolate the reusable function;
4. remove, abstract or bound local and private dependencies;
5. check whether the destination already owns the responsibility;
6. choose the smallest sovereign broader destination;
7. integrate only the public-safe generalized mechanism;
8. preserve origin and transformation lineage;
9. read back the destination;
10. record the selected disposition, including no_delta_with_reason where applicable.

Promotion is not copy/import. A source can influence a public method without becoming a public dependency, and a donor can remain the authority for its own local state. Promotion is deliberate, not automatic.

### Interior–Membrane handoff

When promotion begins from a high-resolution working analysis, use the [Interior–Membrane Split](SIGNAL_CALIBRATION.md#interior-membrane-split) to keep exploration and circulation as different responsibilities. Remove or abstract local and private dependencies without erasing the reusable mechanism, and preserve or lower the donor material's epistemic strength unless new evidence independently raises it. This is a promotion boundary, not a second promotion owner.

## 2. Mutation contract

### Smallest sovereign destination

Before writing, identify the smallest current source that actually owns the responsibility being changed.

Prefer, in order:

1. a sentence, bullet or existing rule in the canonical source;
2. an affected section of that source;
3. a specialized method or state file;
4. a new section in the method's existing owner;
5. a new file only when no current owner can carry the responsibility coherently.

Do not patch a README to change a method whose canonical owner is a specialized file. Do not patch an archive to change current state. Do not patch a mirror, bridge or snapshot instead of its canonical source. Do not copy one new law across several files merely for visibility.

Cross-links are routing. They do not create duplicate authority.

### Readback

Every material mutation closes through readback:

1. reread the changed source from the real external state;
2. verify that the intended delta is present;
3. verify that adjacent responsibilities were not overwritten;
4. verify that links, successor pointers and lineage references resolve;
5. check for a stale active state, contradictory claim or orphan route;
6. accept only after the resulting source has one coherent current reading for each affected slot.

A tool response, commit, upload or merge is a receipt of an action. It is not, by itself, proof that the governing source now says what the operation intended.

### No delta

When the proposed material is already present, not materially different, too weakly evidenced or outside the source's jurisdiction, do not create cosmetic churn.

Return:

~~~text
no_delta_with_reason
~~~

The reason should state whether the source already contains the function, the evidence does not clear the mutation gate, the destination is wrong, or the material should be retained, incubated, rejected or routed elsewhere. No change is a successful operational result when it preserves source integrity.

### Write authority and failure

Metabolize and promote require resolved jurisdiction, a verified current source and a mutation path that preserves reversibility and lineage. A connector's write capability does not grant semantic authority.

If a write succeeds but readback or source acceptance fails, the state is written_unverified or write_succeeded__source_acceptance_failed until repaired or verified. Do not stack another append to explain the failure. Discover the real state first.

## 3. Promotion gate

A donor mechanism is eligible for public promotion only when the evidence materially supports all of these conditions:

1. **Recurrence or operational proof:** it survived more than one accidental use, or its general necessity is otherwise strongly evidenced.
2. **Cross-context value:** the function matters beyond the donor's immediate personal or project habitat.
3. **Semantic stability:** the core behavior is stable enough to document without fossilizing a live experiment.
4. **Bounded dependencies:** local dependencies can be removed, abstracted or explicitly bounded.
5. **Sanitizability:** private, personal and sensitive material is not loadbearing to the public mechanism.
6. **No public duplication:** the destination does not already own the same responsibility sufficiently.
7. **Lineage recoverability:** origin and material transformation can remain traceable.
8. **Claim proportionality:** publication does not inflate a method into an implemented autonomous product.
9. **Maintenance proportionality:** the addition does not create more authority surfaces than the function requires.

A candidate that fails one of these conditions is not a failed idea. It has a different disposition.

| Disposition | Meaning |
|---|---|
| retain_local | Keep the mechanism in its current jurisdiction because local context remains loadbearing. |
| incubate | Preserve it as a candidate while recurrence, evidence, stability or destination remains incomplete. |
| abstract_then_reassess | Extract the general function and run the gate again without publishing the donor habitat. |
| promote | Integrate the generalized mechanism into the smallest sovereign broader destination. |
| already_public | The public source already owns the responsibility; do not create a weaker duplicate. |
| reject | Do not preserve or publish the candidate when it is unsupported, unsafe, duplicative or without a useful destination. |
| no_delta_with_reason | The proposed promotion produces no eligible public change, with the reason recorded. |

Promotion does not erase the donor's lineage, create donor endorsement, transfer private authority or prove external adoption.

## 4. Lifecycle and incubation

A public lifecycle may remain compact:

~~~text
raw_signal
  → incubated_candidate
  → active_mechanism
  → retained_in_jurisdiction
  → promoted_or_generalized
  → deprecated
  → legacy_or_archive
~~~

The flow is not a promise that every candidate reaches every state. Side or terminal dispositions include:

- discarded;
- rejected;
- superseded;
- no_delta_with_reason.

Incubation is not canonization. A documented candidate does not gain authority merely because it has a name or file. Active authority is jurisdiction-specific. Promotion changes the destination of a reusable function; it does not erase its source lineage. A deprecated or legacy artifact may remain retrievable without competing with the current authority.

The active source should answer what is current. A ledger, checkpoint or event record may preserve how the state changed and may trigger review, but it does not rewrite policy by being newer.

## 5. Legacy successor contract

### Mother law

> A superseded source may remain historically retrievable without remaining current authority.

A legacy artifact must be visibly superseded and point current-use questions to its active successor. Historical questions may still use the preserved body when that body has retrieval value.

### Portable legacy metadata

When an artifact needs an explicit succession marker, preserve the following semantics in the local format:

~~~yaml
legacy:
  status: legacy
  source_id: <stable id or path>
  first_active_at: <date or timestamp if known>
  superseded_at: <date or timestamp>
  active_successor: <canonical current path or URI>
  last_active_ref: <version, commit, revision or timestamp when available>
  reason_for_supersession: <concise reason>
  preserved_for:
    - provenance
    - recovery
    - unique_decisions
    - historical_evidence
  semantic_mutation_policy: frozen
  current_resolution_policy: redirect_to_active_successor
  recovery_ref: <Git revision, archive route or source revision>
~~~

Field names may adapt to the host repository. The semantics may not be dropped merely because a file has no YAML front matter.

### Timestamped preservation

Preserve a full superseded body as an explicit immutable artifact only when its path, decisions, lineage or research value justify that weight.

Preferred naming:

~~~text
<original-stem>__legacy__YYYY-MM-DD.md
~~~

Use a more precise timestamp only when same-day transitions make ordering ambiguous. Mark the artifact as frozen and include the active successor. Do not apply new semantic patches to the frozen body merely to keep it current.

### Git history versus explicit archive

Use Git history alone when recovery is sufficient, no stable old path must remain discoverable and the old body has no independent retrieval value.

Use an explicit archive or timestamped legacy artifact when:

- a retained path or URL is materially useful;
- historical decisions are easier to recover as a bounded artifact;
- lineage or research value justifies preserving the body;
- a visible successor pointer prevents stale-authority confusion.

Do not duplicate every old file into archive by ritual. History is a carrier of the past, not a second current source.

## 6. Source body, history and cross-system transport

### The source governs; the ledger witnesses

The governing source answers what is current now. A history, event log, checkpoint, changelog or ledger answers what happened and how the state reached its current form.

A newer ledger entry does not automatically supersede the governing source. A ledger may trigger review, but current state changes only through the appropriate source operation and authority path. Distill current state into the source instead of appending endless chronology to its body.

### Bridge and snapshot laws

- **Bridge is not governing source.** A bridge routes or translates between jurisdictions; circulation does not give it authority over either source.
- **Snapshot is not living source.** A dated capsule or export is valid for its time and scope; it does not silently become current after the living source changes.
- **Canonical home is not defined by circulation.** Mirrors, exports, references and convenience surfaces do not become canonical because they are easier to reach.
- **External influence is not blind import.** Preserve origin and credit, extract the functional delta, distinguish adopted, adapted and rejected elements, and keep donor identity and private habitat outside the public mechanism.

For the dedicated custody and attribution operation, use [Credits & Attribution Ops](CREDITS_ATTRIBUTION_OPS.md). For connected-source access, freshness, permissions and connector readback, use the canonical [Connected Sources](CONNECTED_SOURCES.md) capability.

## 7. Relationship to adjacent components

| Component | Owns | Source Operations adds |
|---|---|---|
| [Preflight](https://github.com/luahelenammc/Moon-Source/blob/main/docs/PREFLIGHT.md) | task shaping before execution | the operation chosen after intent, authority, destination and risk are clear |
| [Connected Sources](CONNECTED_SOURCES.md) | connector reach, source/data authority, freshness, scope and readback | the semantics of retrieve, process, metabolize and promote once a source is reached |
| [Source Hygiene](SOURCE_HYGIENE.md) | diagnosis of stale, contradictory, duplicated or bloated corpus material | mutation, succession and no-delta rules after a finding is confirmed |
| [Responsibility Map](RESPONSIBILITY_MAP.md) | ownership and authority between objects | the operation contract that moves a delta through the owning source |
| [Archive and Legacy](https://github.com/luahelenammc/Moon-Source/blob/main/archive/README.md) | preserved history and non-current artifacts | the reusable successor contract and current-use versus historical-use distinction |
| [Credits & Attribution Ops](CREDITS_ATTRIBUTION_OPS.md) | material lineage, custody, permission and attribution | promotion's origin and transformation boundary |
| [AI Kernel](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_AI_KERNEL.md) | public AI boot and routing | the route into this method surface |
| [Adaptive Orchestration Protocol](../portables/adaptive-orchestration/ADAPTIVE_ORCHESTRATION_PROTOCOL.md) | object-routed Chat, Work and Codex execution, budget survival and post-execution closure | no change to the orchestration lifecycle |

This file owns the operation grammar. The adjacent components remain authoritative for their own responsibilities.

## 8. Minimal operating worksheet

Use the smallest record that makes a source operation auditable:

~~~text
operation: retrieve | process | metabolize | promote
source_or_donor:
jurisdiction_or_facet:
current_authority:
current_state_read:
real_delta:
smallest_sovereign_destination:
lineage_and_boundary:
readback:
disposition:
~~~

For retrieve or process, the disposition may be analytic_only, patch_candidate or no_delta_with_reason. For metabolize, it must include the readback result. For promote, it must include the gate result and the material origin/transformation boundary.

## Claim ceiling

This component supports the claim that Moon Source publishes a bounded source-operations and lifecycle method with retrieve/process/metabolize/promote distinctions, a promotion gate, legacy-successor semantics, readback, no-delta and authority-safe transport rules.

It does not support claims of:

- an autonomous source migration, promotion or archive engine;
- autonomous or background detection of promotion eligibility;
- automatic synchronization or archive creation;
- external adoption, measured impact or universal validity;
- permission or endorsement from an upstream donor;
- perfect semantic enforcement by every model or connector.

Documentation is a real public method surface. It is not a robot with a clipboard.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).