# Preflight — canonical portable moved

Preflight is now a standalone Moon Source public portable, currently at version **2.3**.

**Current canonical path:** [`portables/preflight/PREFLIGHT.md`](https://github.com/luahelenammc/Moon-Source/blob/main/portables/preflight/PREFLIGHT.md)<br>
**Current version:** 2.3  
**Portable promotion:** 2026-09-07

This file is a succession pointer, not a second semantic body. The former component body and Preflight V1 lineage remain recoverable through Git history. For current use, load the canonical portable above.

> Humans should not have to prompt like machines.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
