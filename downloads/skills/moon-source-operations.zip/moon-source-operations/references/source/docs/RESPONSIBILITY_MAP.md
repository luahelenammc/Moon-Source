# Responsibility Map

The following objects can work together, but they do not perform the same job.

**MSL profile:** 5.1-compatible Markdown-native mapping surface; responsibility, authority and boundaries remain explicit.

| Object | Public reading | Primary responsibility | It is not |
|---|---|---|---|
| Field | The real situation | Supply the context that must be understood | A document template |
| Source | Governed context | Hold facts, decisions, rules or material with an authority boundary | Every note ever written |
| Living source | Updateable governed context | Keep scope, freshness, owner and active state visible | A chat transcript |
| Source Operations | Public operation grammar | Distinguish retrieve, process, metabolize and promote, with mutation, lifecycle, succession, readback and no-delta rules | A source of facts, a connector or an autonomous migration engine |
| Connected source | Reachable governed external context | Expose a source through a connector while preserving authority, jurisdiction, freshness, provenance and verification | Authority merely because it is reachable |
| Source substrate | Persistent accessible source body | Preserve stable identity, retrieval, freshness, permissions and history for living-source operation | A vendor-specific ontology or automatic source of truth |
| Connector / app | Bounded access or action surface | Carry read, search or authorized action capability between the AI and a substrate | Mutation authority, exhaustive understanding or semantic ownership |
| Context Receipt | Context-path evidence | Record the governing sources, authority, freshness, scope, exclusions and verification that materially justified a result | A mandatory ceremony, a source of authority or a substitute for ordinary operation evidence |
| Project | Bounded work domain | Define purpose, jurisdiction, participants and outputs | A single task |
| Procedure | Reusable way of working | Describe how an operation is performed | A source of truth for all facts |
| Skill | [Portable procedural projection](https://github.com/luahelenammc/Moon-Source/blob/main/docs/PROCEDURAL_PROJECTION.md) | Trigger and execute a reusable procedure | A magical capability or private corpus |
| Operational device | Bounded operational embodiment | Execute a reusable procedure on a named surface with state, guards, failure behavior and receipts | Semantic authority, unrestricted automation or new privilege |
| Task | One bounded action or recurring obligation | Move a project or source through a concrete next step | A project architecture |
| Handoff | Transfer of responsibility and state | Let another person, model or thread continue safely | A complete backup of the corpus |
| Packet / capsule | Bounded transport envelope | Carry objective, state, limits, provenance and next actions | A new authority by itself |
| Bridge | Translation between systems | Preserve meaning across jurisdictions without owning either source | Silent authority transfer |
| Ledger / registry | Structured record | Track decisions, identities, versions, checkpoints or lineage | A full narrative archive |
| Intellectual custody / Credits & Attribution Ops | Immaterial-asset protection layer | Keep content identity, origin, authorship, canonicality, transformations, permission boundaries, derivatives, attribution and evidence recoverable as material moves or changes | A licence, legal rights resolver, ownership proof or enforcement mechanism |
| Attribution record | Public or bounded lineage output | Carry the proportionate credit and lineage facts a material descendant needs | The whole custody system or a grant of permission |
| Protocol | Repeatable operating rule | Set conditions, sequence, boundaries and acceptance | A runtime implementation |
| Runtime | Callable operating capacity | Execute a bounded operation and return observable state or receipts | A synonym for documentation |
| Public surface | Human-facing entry point | Explain, distribute or route public material | The semantic source of truth |
| Archive / legacy | Preserved history | Retain prior states without governing the present | The current active source |
| MSL | Structural/context grammar for governed semantic passage | Choose proportionate form and preserve passage laws | Executable code, a runtime or a universal ontology |

## Canonicalization rule

One capability has one active semantic body. A portable may also own a structural responsibility; portability describes how that body travels, not a second copy of what it means. Mirrors and packages are delivery surfaces, adapters own only genuinely volatile or surface-specific facts, and history belongs to Git rather than an active compatibility twin.

## Use the responsibility map

Apply the map to an existing set of files, objects or workflows before creating new categories:

```text
Use the Moon Source Responsibility Map on the system below.

For each important item, identify:
1. what responsibility it currently appears to perform;
2. what responsibility it should own;
3. whether it is overloaded, duplicated or carrying another object's authority;
4. which object should remain authoritative;
5. the smallest repair: split, merge, relabel, bridge, handoff, protocol, archive or no change;
6. what must remain current and what should be demoted to lineage or archive.

Prioritize repairing ownership and transport. Do not generate every Moon Source object type unless the field requires it.

System:
[paste the file list, folder layout, workflow or object descriptions]
```

If the field itself is still unclear, begin with the [Field-to-Form diagnostic](https://github.com/luahelenammc/Moon-Source/blob/main/ARCHITECTURE.md#field-to-form). For the operation chosen after the field and authority are clear, use [Source Operations](SOURCE_OPERATIONS.md). If a structural artifact or handoff is needed, use [Moon Source Language](https://github.com/luahelenammc/Moon-Source/blob/main/portables/msl/MOON_SOURCE_LANGUAGE.md). If a procedure needs a concrete execution surface, use [Operational Devices](https://github.com/luahelenammc/Moon-Source/blob/main/docs/OPERATIONAL_DEVICES.md) with [Operational Reliability](https://github.com/luahelenammc/Moon-Source/blob/main/docs/OPERATIONAL_RELIABILITY.md). If intellectual material needs identity, lineage or custody protection while it moves, changes, forks, mirrors or passes through AI, use [Credits & Attribution Ops](CREDITS_ATTRIBUTION_OPS.md). If the unresolved issue is where ChatGPT work should run, use the [Adaptive Orchestration Protocol](../portables/adaptive-orchestration/ADAPTIVE_ORCHESTRATION_PROTOCOL.md).

**Download the full public Moon Source:** [complete repository (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip). For individual files and portables, use the [download hub](https://github.com/luahelenammc/Moon-Source/blob/main/DOWNLOADS.md).

## Reading rule

When two objects appear to overlap, ask which responsibility is actually changing. Similar content does not make the objects interchangeable.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
