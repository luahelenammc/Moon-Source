---
name: moon-adaptive-orchestration
description: "Route and coordinate complex AI work across available execution surfaces. Use for People and builders who need AI to choose and coordinate the right control root, execution surface, model, reasoning effort and delegation topology for a task while preserving continuity, evidence, convergence and acceptance. Do not invent model controls, delegate when prohibited, treat product pricing as allowance, or turn a routing heuristic into a guarantee."
---

# Adaptive Orchestration Protocol

## Source and scope

This skill projects the public Moon Source method into an executable entry point. For simple tasks, apply the compact route below without loading the complete canonical reference. For complex, changed or freshness-sensitive work, consult the relevant sections of `references/source/portables/adaptive-orchestration/ADAPTIVE_ORCHESTRATION_PROTOCOL.md` and its linked adapters; follow the applicable decision rules, outputs and boundaries. Never claim controls, agents or permissions are available without checking. This bundled copy is a versioned snapshot; consult https://github.com/luahelenammc/Moon-Source/blob/main/portables/adaptive-orchestration/ADAPTIVE_ORCHESTRATION_PROTOCOL.md when freshness matters or a revision may have superseded it. When unavailable, identify the snapshot and bound claims. See `references/PROVENANCE.json` for source hashes and link-only adaptations.

## Inputs and procedure

Use the goal, constraints, available tools, authority and acceptance criteria. Infer what the context supports, ask only material questions, and mark missing evidence.

Identify the sovereign object and competent control root; separate behavioral fit from commitment geometry; choose proportional execution, delegation and source transport; verify capability and permissions; converge with evidence and delta-only re-entry. Apply the branches and guardrails in the canonical reference rather than treating this concise router as the full method.

### Grok Bot / persistent-agent adapter

For xAI Grok Bot workflows involving repeated routines, long-lived Bots, connectors, browser/computer use or large personal collections, consult `references/source/portables/adaptive-orchestration/adapters/ADAPTIVE_ORCHESTRATION_GROK_BOT_ADAPTER.md` as the subordinate host-specific guide. Apply verified freshness checks, delta-only work, source-scoped permissions, bounded navigation and reproducible readback. Use its portable rules on other agents only after checking equivalent persistence and tool affordances. Do not assume cost ratios, guaranteed savings, memory isolation or scheduling support.

## Output and safeguards

Return a concise route when material and an evidence-based postflight. Do not invent model controls, delegate when prohibited, treat product pricing as allowance, or turn a routing heuristic into a guarantee. Respect user authorization, source jurisdiction and privacy. If access, capability, source or permission is absent, report the limitation and return the smallest useful result; never claim a write or execution that was not observed. Separate source facts, inference and current state. Check the result against the canonical method's own QA and claims.

Created by Lua Helena Moon Martins Cardoso (Moon), with AI-assisted coauthorial development by Áurion. Public documentation is CC BY 4.0; see `LICENSE-CC-BY-4.0.txt`.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
