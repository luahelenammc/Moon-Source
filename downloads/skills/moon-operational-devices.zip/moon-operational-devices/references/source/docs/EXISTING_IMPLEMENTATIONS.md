# Existing Implementations and Projections

This map points to artifacts that already exist. It is not a manufactured case study and does not claim external adoption.

Use it to choose an inspectable public capability. If the question is what should be created rather than what already exists, start with the [🏗️ Architecture — Field to Form](https://github.com/luahelenammc/Moon-Source/blob/main/ARCHITECTURE.md#field-to-form).

**How does documented method become a real system?** [From method to implementation](https://github.com/luahelenammc/Moon-Source/blob/main/docs/FROM_METHOD_TO_IMPLEMENTATION.md) explains proof levels, implementation responsibilities and a smallest-test contract. A separately hosted [synthetic knowledge-routing demonstrator](https://www.luahelena.com.br/ia/demos/governed-knowledge/) illustrates a related governance behavior with deterministic rules. It is a companion example in another repository, **not a client deployment or evidence that Moon Source is a packaged SDK**.

**Download the full public Moon Source:** [complete repository (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip). For individual files and portables, use the [download hub](https://github.com/luahelenammc/Moon-Source/blob/main/DOWNLOADS.md).

## Public artifacts

| Capability | Inspectable materialization | Evidence class | Claim ceiling |
|---|---|---|---|
| Human-intent reconstruction before execution | [Preflight](https://github.com/luahelenammc/Moon-Source/blob/main/portables/preflight/PREFLIGHT.md) | PUBLIC_ARTIFACT, PUBLIC_REPOSITORY | A documented public method reconstructs intended tasks from ordinary human expression and activates heavier execution guardrails only when consequence requires them; mind-reading, scientific validation, uniqueness, adoption, measured improvement and independent validation are not demonstrated here. |
| Personal context setup | [Setup](https://github.com/luahelenammc/Moon-Source/blob/main/portables/setup/MOON_SOURCE_SETUP.md) | PUBLIC_ARTIFACT | An adaptive setup is published, now with a bounded capability-probed persistent-source route; impact is not demonstrated here. |
| Contextual scene reading | [Be My Eyes 1.0-public portable](https://github.com/luahelenammc/Moon-Source/blob/main/portables/be-my-eyes/BE_MY_EYES.md) | PUBLIC_ARTIFACT, PUBLIC_REPOSITORY | One canonical public body serves both the structural method and independently readable portable for scene reconstruction, observation/inference separation, relational structure, subtext, overread, plausible reception and response-axis selection; mind-reading, diagnosis, validated prediction, guaranteed reaction and external adoption are not demonstrated. |
| Sovereign semantic passage grammar | [Moon Source Language](https://github.com/luahelenammc/Moon-Source/blob/main/portables/msl/MOON_SOURCE_LANGUAGE.md) | PUBLIC_ARTIFACT | Moon Source Language version 5.1 is published as a structural/context portable; it is not executable code or a universal standard. |
| Procedural projection method | [Procedural Projection](PROCEDURAL_PROJECTION.md) | PUBLIC_ARTIFACT | A bounded public method exists; automatic synchronization, native execution everywhere and impact are not demonstrated. |
| Operational Device Pattern | [Operational Devices](OPERATIONAL_DEVICES.md) | PUBLIC_ARTIFACT | A bounded public operational-embodiment contract exists; universal runtime support, automatic adapters and cross-surface stability are not demonstrated. |
| Operational Reliability | [Operational Reliability](OPERATIONAL_RELIABILITY.md) | PUBLIC_ARTIFACT | A public execution-discipline method exists with ordinary and materiality-triggered Context Receipts; safety, diagnosis correctness, autonomous repair and recovery in every environment are not demonstrated. |
| Failure to Capability / Failure Foundry | [Failure to Capability — Failure Foundry](FAILURE_FOUNDRY.md) | PUBLIC_ARTIFACT | A bounded failure-to-capability projection exists; it is not an autonomous self-improvement engine, compiler or measured-impact claim. |
| Browser Console Device reference | [browser-console-device/](https://github.com/luahelenammc/Moon-Source/tree/main/examples/browser-console-device) | IMPLEMENTED_BOUNDED / INCUBATING | A synthetic `localhost` reference is implemented and bounded; it is not a current portable, production crawler or universal browser runtime. |
| Longitudinal conversational re-entry and human handoff (synthetic example, not a registered capability) | [Context selector, re-entry evaluator and Node.js tests](https://github.com/luahelenammc/Moon-Source/blob/main/examples/conversational-context/README.md) | IMPLEMENTED_BOUNDED, TESTED_BOUNDED | The pure functions can filter approved fictional records, detect changed/current state and recommend or record requested human review without sending messages; no user identity, live consent, external notification, production security or deployment is demonstrated. |
| First-use project-context walkthrough | [Fictional walkthrough](https://github.com/luahelenammc/Moon-Source/blob/main/examples/first-use-project-context.md) | PUBLIC_ARTIFACT / HYPOTHETICAL | A written example shows authority and freshness checks over invented source records; it is not an executed integration, case study, validation or measured result. |
| Source-hygiene / Project MRI method | [Source Hygiene](https://github.com/luahelenammc/Moon-Source/blob/main/docs/SOURCE_HYGIENE.md) | PUBLIC_ARTIFACT | A bounded diagnostic surface exists; it is not a finished autonomous scanner or repair engine. |
| Connected-source operation | [Connected Sources 1.2](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONNECTED_SOURCES.md) | PUBLIC_ARTIFACT, PUBLIC_REPOSITORY | One canonical public body serves the structural crown-jewel capability and its independently readable standalone distribution for connector-aware source/data and instruction authority, host reach distinct from consumer-scoped delivery, four operating modes, freshness, progressive retrieval scope, rehydratable source offload, mutation boundaries, readback and fallback; Google Drive is a ChatGPT reference substrate and GitHub is complementary for executable facets, not proof of universal product support or adoption. Dated product facts are isolated in the subordinate [ChatGPT adapter notes](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONNECTED_SOURCES_CHATGPT_ADAPTER.md). |
| Source operations and lifecycle | [Source Operations](https://github.com/luahelenammc/Moon-Source/blob/main/docs/SOURCE_OPERATIONS.md) | PUBLIC_ARTIFACT | A bounded public method exists for retrieve, process, metabolize and promote, promotion gates, lifecycle, legacy succession, smallest sovereign destination, readback and no-delta; it is not an autonomous migration or promotion engine. |
| Qualitative signal / inference calibration | [Signal Calibration](https://github.com/luahelenammc/Moon-Source/blob/main/docs/SIGNAL_CALIBRATION.md) | PUBLIC_ARTIFACT | A bounded public method exists; it does not prove motives, diagnostic validity, external adoption or impact. |
| Intellectual-lineage and immaterial-asset protection | [Credits & Attribution Ops](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CREDITS_ATTRIBUTION_OPS.md) | PUBLIC_ARTIFACT | A bounded public content-custody method exists for identity, lineage, transformations, permission envelopes, disclosure boundaries, derivatives, attribution and evidence; it is not a licence, legal rights resolver, enforcement mechanism or proof of ownership. |
| Adaptive Orchestration | [Adaptive Orchestration Protocol](https://github.com/luahelenammc/Moon-Source/blob/main/portables/adaptive-orchestration/ADAPTIVE_ORCHESTRATION_PROTOCOL.md) | PUBLIC_ARTIFACT | The current tri-surface routing protocol is published; product/model calibration remains date-sensitive and no native-skill installation claim follows from the portable alone. |
| Public human-facing portal | https://www.luahelena.com.br/moonsource/?lang=en | PUBLIC_REPOSITORY | The website distributes and explains public material; it is not the semantic authority for the repository. |
| Professional context | https://www.luahelena.com.br/ia/?lang=en | PUBLIC_REPOSITORY | The page presents Moon's professional context; it is not a case study of client adoption. |
| Public reference body | https://github.com/luahelenammc/Moon-Source | PUBLIC_REPOSITORY | The repository versions public-safe architecture and portables; it is not a product or SDK. |

## Hypothetical application gallery

The [application-scenario gallery](https://github.com/luahelenammc/Moon-Source/tree/main/examples/application-scenarios) is a public explanatory artifact, not an implementation record. It contains eight explicitly hypothetical / fictional didactic scenarios covering health and care, public services, customer journeys, company operations, transparency and audit, people and learning, third-sector coordination, and knowledge/data continuity.

Its evidence class is `PUBLIC_ARTIFACT` only for the existence and inspectability of the scenario files. It does not establish real adoption, implementation, measured impact, sector validation, independent validation or a client case. The scenarios route to actual public components and portables while keeping the claim ceiling unchanged.

## What is intentionally absent

- no synthetic blank-field case;
- no invented before-and-after;
- no control negative;
- no external adoption story;
- no private corpus or client material;
- no full resolver, compiler or reconciliation internals.

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
