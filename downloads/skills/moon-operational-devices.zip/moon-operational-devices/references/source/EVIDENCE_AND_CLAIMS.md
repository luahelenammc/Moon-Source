# Evidence and Claims

Moon Source is disclosed through existing evidence only. This repository organizes artifacts that already exist; it does not manufacture a case to justify the architecture.

## Evidence classes

| Class | Meaning |
|---|---|
| PUBLIC_ARTIFACT | A deliberately published portable or public-facing file can be inspected directly. |
| PUBLIC_REPOSITORY | A public repository or path exposes the claimed implementation or documentation. |
| IMPLEMENTED_BOUNDED | A bounded implementation exists, but the claim is limited to the observed slice. |
| TESTED_BOUNDED | A bounded test or verification supports a narrowly stated technical claim. |
| PLANNED | The work is intended but not yet implemented or released. |
| NOT_DEMONSTRATED | The available evidence does not establish the claim. |

## What the current public body supports

- A subordinate [Conversational Context integration contract](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CONVERSATIONAL_CONTEXT.md), [jurisdictional requirements boundary](https://github.com/luahelenammc/Moon-Source/blob/main/docs/JURISDICTIONAL_REQUIREMENTS.md) and [deterministic synthetic Node.js example](https://github.com/luahelenammc/Moon-Source/blob/main/examples/conversational-context/README.md) illustrate longitudinal journey re-entry, purpose/consent-bound context reuse and honest human-review recommendations. The existing selector determines which fictional current fields are eligible; the re-entry evaluator consumes its result and distinguishes `handoff_recommended` from `handoff_requested` without claiming delivery. Evidence: PUBLIC_ARTIFACT, PUBLIC_REPOSITORY and IMPLEMENTED_BOUNDED; TESTED_BOUNDED for the synthetic behavior when the repository's automated test run passes. This does not demonstrate identity enforcement, real-world consent validity, actual notification, legal compliance, externally deployed AI products, clinical support, real participant data handling, model reliability or third-party adoption.


- Moon Source is a public context-architecture method and reference architecture. Evidence: PUBLIC_ARTIFACT, PUBLIC_REPOSITORY.
- A separate public [Moon Cortex repository](https://github.com/luahelenammc/Moon-Cortex) exists as a related applied/system body for domain-shaped modules. This establishes a public relationship and discoverability route, not that Cortex is a Moon Source capability, permanent dependency or adoption claim. Evidence: PUBLIC_REPOSITORY.
- Moon Source includes independently readable public portables for setup, human-intent reconstruction, contextual scene reading, connected sources, adaptive structural grammar and adaptive orchestration. Evidence: PUBLIC_ARTIFACT.
- Moon Source Language is the current public structural/context language in this repository, at version 5.1. Evidence: PUBLIC_ARTIFACT. MSL 5.1 is not an executable language, universal ontology, runtime or adoption claim.
- The repository is a public versioning and reference body. Evidence: PUBLIC_REPOSITORY.
- The public body includes **Preflight**, currently version 2.1, a documented human-intent reconstruction method that converts ordinary, incomplete, conversational or self-correcting expression into a faithful working task before execution and activates heavier source/freshness/provenance/risk/destination/mutation guardrails only when consequence materially requires them. Evidence: PUBLIC_ARTIFACT, PUBLIC_REPOSITORY. This establishes the existence and inspectability of the method, not mind-reading, scientific validation, uniqueness, universal superiority, external adoption, independently measured prompting improvement or downstream impact.
- A bounded public procedural-projection method exists. Evidence: PUBLIC_ARTIFACT; this does not establish automatic Source ↔ Skill synchronization or native execution in every environment.
- A bounded public source-hygiene / Project MRI method exists. Evidence: PUBLIC_ARTIFACT; this does not establish an autonomous scanner, repair engine or measured impact.
- A bounded public Connected Sources capability and independently readable 1.2 standalone distribution exist for connector-aware source/data authority, instruction authority, jurisdiction, consumer-scoped delivery, freshness, retrieval scope, rehydratable offload that preserves a resolvable source, mutation authority, readback and explicit standalone/connected-read/living-source/federated modes, including proportional progressive context loading. Its canonical body is docs/CONNECTED_SOURCES.md. Evidence: PUBLIC_ARTIFACT, PUBLIC_REPOSITORY; the dated ChatGPT adapter records a Google Drive document-source reference and complementary GitHub executable-source role, but does not establish universal connector support, automatic synchronization, exhaustive retrieval, authority by locator, external adoption or measured impact.
- A bounded public signal / inference calibration method exists for separating observation, convergence, working inference, meaningful alternatives, uncertainty and established claims. Evidence: PUBLIC_ARTIFACT; this does not establish proof of motive, diagnostic validity, scientific validation, external adoption or measured impact.
- A bounded public Credits & Attribution Ops component exists for intellectual lineage, content custody and immaterial-asset protection across identity, origin, authorship, transformations, permission envelopes, disclosure boundaries, derivatives, attribution and evidence. Evidence: PUBLIC_ARTIFACT; this does not establish legal ownership, resolve third-party permission, provide enforcement, imply endorsement, establish external adoption or automatically resolve provenance. Legal reuse permission for Moon Source files is routed separately through the applicable standard license.
- A bounded public Operational Device responsibility pattern exists for embodying a reusable procedure on a concrete execution surface. Evidence: PUBLIC_ARTIFACT; this does not establish a universal runtime, automatic adapter generation, new permissions or cross-surface stability.
- A bounded public Operational Reliability method exists for read-only-first diagnosis, dependency checks, failure-domain separation, ordinary receipts and materiality-triggered Context Receipts, reversibility and freshness gates. Evidence: PUBLIC_ARTIFACT; this does not guarantee safety, diagnosis correctness, autonomous repair or recovery in every environment.
- A bounded public Failure to Capability / Failure Foundry projection exists for metabolizing recurring failure into the smallest validated reusable mechanism. Evidence: PUBLIC_ARTIFACT; this is not an autonomous self-improvement engine, compiler, benchmark or measured-impact claim.
- A synthetic Browser Console Device reference implementation exists for a narrow `localhost` surface. Evidence: IMPLEMENTED_BOUNDED, TESTED_BOUNDED; this does not establish a production crawler, universal browser runtime, automatic adapter generation, completeness, cross-site stability or external adoption.
- The public examples gallery contains eight fictional application scenarios. Evidence: PUBLIC_ARTIFACT for the existence of explanatory files only; the scenarios do not establish implementation, adoption, measured impact, sector validation or independent evidence.
- The website is a human-facing public surface and the professional page is a separate professional context. Evidence: PUBLIC_REPOSITORY and public URLs.

## Third-party public references (observed 2026-11-06)

A distinct GitHub account, `ChrisCanadian`, publicly credits Moon Source's [Credits & Attribution Ops Protocol](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CREDITS_ATTRIBUTION_OPS.md) as **reference / inspiration for the presentation of attribution and provenance records** in four currently accessible repositories:

- [Live Runtime Acceptance Rig · ATTRIBUTION.md](https://github.com/ChrisCanadian/Live-Runtime-Acceptance-Rig/blob/main/ATTRIBUTION.md)
- [Nexus Proof Runtime · PROVENANCE.md](https://github.com/ChrisCanadian/nexus-proof-runtime/blob/main/PROVENANCE.md)
- [Nexus Mode Card Creator · ATTRIBUTION.md](https://github.com/ChrisCanadian/nexus-mode-card-creator/blob/main/ATTRIBUTION.md)
- [Nexus Memory Kernel · ATTRIBUTION.md](https://github.com/ChrisCanadian/Nexus-Memory-Kernel/blob/main/ATTRIBUTION.md)

**What this supports:** four public attribution references under **one other GitHub account**, identifying a specific Moon Source method as a source of inspiration for an attribution practice. The linked files were read in their default branches on the observation date.

**What this does not support:** four independent adopters, code reuse, package dependency, runtime integration, validated deployment, measurable results, endorsement, partnership, or significant ecosystem dependence. The external records explicitly limit the relationship to attribution practice. Treat this as public **reference evidence**, not as adoption or an ecosystem-impact threshold. Counts and link validity must be rechecked before future publication.

## What the current public body does not establish

Public artifact is not adoption.

A documented method is not evidence of external validation.

A tested slice is not full runtime proof.

A materialized skill is not proven impact.

A repository is not product-market fit.

A reference architecture is not a universal standard.

This repository does not claim:

- external adoption or independently validated outcomes;
- validated enterprise deployment or enterprise readiness;
- universal superiority over other context systems;
- a universal standard;
- a general software engine or hosted service without corresponding public implementation evidence;
- automated cross-platform synchronization beyond the explicit mirror checks;
- automatic permission, legal ownership, authorship, provenance or attribution resolution;
- cryptographic proof of authorship merely because a fingerprint is present;
- product-market fit, return on investment or downstream impact.

## Hypothetical application scenarios are not evidence

The files under `examples/application-scenarios/` are intentionally labeled **hypothetical / fictional didactic scenarios**. Each example illustrates how Moon Source could be applied to a common context problem; it is not evidence of external adoption, implementation, measured impact or independent validation.

Do not rename these files as case studies, client cases, proven results, adoption examples or validated deployments. Do not add real patient, client, institution or organization material, realistic identifiers or invented outcome metrics. The gallery explains the method and its boundaries; it does not raise the public claim ceiling.

## Community-use evidence and verification

The [real-world use report template](https://github.com/luahelenammc/Moon-Source/blob/main/.github/ISSUE_TEMPLATE/usage_report.md) allows external users to voluntarily submit a public, permissioned account of where a specific Moon Source component is used. These reports are leads for verification, **not automatic adoption claims**.

- **REPORTED:** first-hand or third-party account, with date and scope; not yet independently checked.
- **VERIFIED_PUBLIC:** a maintainer has checked a live public implementation or dependency, identified the exact component and version/commit, and confirmed that the cited artifact supports the narrow claim being made.
- **UNVERIFIED_PRIVATE:** usage asserted without public evidence; keep aggregate counts and names out of public claims unless explicit permission and suitable substantiation exist.
- **PLANNED:** prospective or hypothetical use; never count it as an adopter, dependent, download, user, deployment or outcome.

Only count unique independent adopters where the evidence permits deduplication; do not conflate stars, forks, ZIP downloads, synthetic demos, author-owned mirrors, PR volume or GitHub activity with downstream adoption. Maintain provenance for each verified entry, keep consent revocable for public naming, and update or remove stale claims after readback.

**Current claim ceiling:** until individually verified external-use entries exist, the repository continues to make **no claim of independently demonstrated external adoption or ecosystem dependence**. This evidence process does not confer such evidence by itself.

## Claim discipline

`EVIDENCE_AND_CLAIMS.md` governs public claims about Moon Source and should not be interpreted as requiring every useful working inference inside a field to meet publication-grade evidence before it can be stated as an inference.

Every new public claim should answer:

1. What artifact or source supports it?
2. What does that evidence actually demonstrate?
3. What remains outside the evidence?
4. Is the language stronger than the evidence?

If a claim cannot answer those questions, report the evidence gap or label the claim PLANNED or NOT_DEMONSTRATED.

## Public routes

Use [Existing Implementations](docs/EXISTING_IMPLEMENTATIONS.md) to inspect the artifacts behind current claims, the [README](https://github.com/luahelenammc/Moon-Source/blob/main/README.md) for orientation, or [Downloads](https://github.com/luahelenammc/Moon-Source/blob/main/DOWNLOADS.md) for the current public distribution.

For licensing, use [LICENSING.md](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md). For intellectual lineage, content custody and immaterial-asset protection, use [Credits & Attribution Ops](https://github.com/luahelenammc/Moon-Source/blob/main/docs/CREDITS_ATTRIBUTION_OPS.md). For Moon Source-specific use framing, authorship and the repository footer/watermark, use [Moon Source Use & Attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md).

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
