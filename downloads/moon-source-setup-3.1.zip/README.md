# 🧭 Moon Source Setup

A public portable that finds the **smallest useful AI context setup for what you actually want to do**.

You do not need to decide whether you are a beginner, power user or builder before starting. Moon Source Setup begins from your need, destination and privacy boundary, then infers how much structure is useful. The current public version is **3.1**. It also routes durable continuity or current-source needs to Connected Sources when a persistent substrate is actually available, while retaining a standalone fallback.

[⬇️ **Download Moon Source Setup package (.zip)**](https://github.com/luahelenammc/Moon-Source/raw/refs/heads/main/downloads/moon-source-setup-3.1.zip)

> 🌱 **New here? Read [FIRST_USE.md](FIRST_USE.md) before using this portable.** It explains the first action, starter prompt and manual boundaries.

## Start here

Paste `MOON_SOURCE_SETUP.md` into an AI conversation and say:

```text
Execute.
```

The Setup should then:

1. understand what you want AI to do better;
2. inspect useful context or instructions you already have;
3. infer how much structure the situation actually needs;
4. separate general behavior from project-specific context when useful;
5. produce an output sized for its real destination;
6. test the result and tell you what would justify updating it later.

It should **not** make you learn Moon Source vocabulary before receiving value, restart from zero when working material already exists, or create advanced artifacts simply because they are available.

## Two operating modes

### Standalone

`MOON_SOURCE_SETUP.md` works by itself. No other Moon Source file is required for ordinary personal, work, writing, project or repair setups.

### Repository-aware

If the AI also has the full Moon Source repository or ZIP, the Setup detects that broader context and defers repository loading to `MOON_SOURCE_AI_KERNEL.md`.

The rule is simple:

> **Access is not activation.** Moon Source components are capability references, not mandatory context.

Only the smallest relevant component set should be loaded for the actual task.

### Persistent source route

When the need is a current living source or durable cross-session continuity, probe the available source surface before promising connected behavior. Google Drive is the recommended ChatGPT document-source substrate; GitHub is complementary for executable, versioned public material. Neither is mandatory, and an unresolved or unauthorized source falls back to bounded standalone context. See [Connected Sources](../connected-sources/CONNECTED_SOURCES.md).

## Current identity

- 📌 **Version:** 3.1
- 🗂️ **Canonical file:** [MOON_SOURCE_SETUP.md](MOON_SOURCE_SETUP.md)
- 🌐 **Language:** English-first portable; execution follows the user's language
- 🧩 **Standalone dependencies:** none
- 🧭 **Routing model:** need × inferred maturity × destination × sensitivity
- 🔗 **Persistent source route:** Connected Sources when current or durable context earns a source substrate
- 🔧 **Default with existing material:** inspect → diagnose → preserve what works → repair only what is needed
- 🔓 **License:** [CC BY 4.0](../../LICENSES/CC-BY-4.0.txt); share/adapt with credit and change indication
- 📜 **Licensing route:** [LICENSING.md](../../LICENSING.md)
- 🛡️ **Claim ceiling:** published adaptive setup; no adoption, impact or enterprise-readiness claim
- 🧬 **Credits & attribution operations:** [public protocol](../../docs/CREDITS_ATTRIBUTION_OPS.md)

Want the whole public architecture instead? [📦 Download the complete Moon Source repository (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip).

Return to the [🗂️ download hub](../../DOWNLOADS.md) or [📚 portable registry](../../registry/PUBLIC_PORTABLES.md).

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip)
