# Adaptive Orchestration GPT-6 Sol/Luna Strategy Adapter

*Dated executor calibration for the GPT-6 family*

## Meta

- **status:** current subordinate adapter
- **adapter version:** 1.4
- **as of:** 2026-09-29
- **governing capability:** [Adaptive Orchestration Protocol](../ADAPTIVE_ORCHESTRATION_PROTOCOL.md)
- **scope:** GPT-6.1 Sol, GPT-6 Sol and GPT-6 Luna routing in Work and Codex, including heterogeneous subagent topology, child-model inheritance/overrides, token-economy profiles and API/product-boundary reasoning about executor choice
- **authority:** subordinate; the canonical Adaptive Orchestration body wins on conflict
- **volatility:** high; availability, model menus, reasoning controls, plan/workspace exposure and usage economics must be rechecked
- **product boundary:** not OpenAI policy, not a benchmark ranking system and not a guarantee about ChatGPT allowance consumption
- **creator:** Lua Helena Moon Martins Cardoso (Moon)
- **AI-assisted coauthorial development:** Áurion
- **license:** CC BY 4.0 under the repository licensing terms

## 1. Why this adapter exists

GPT-6 changes the practical executor geometry, and current subagent support makes heterogeneous model delegation a first-class execution option under Adaptive Orchestration 6.1. The 6.1 core is surface-neutral: Sol/Luna topology does not require Chat to be the control root when Work or Codex can retain objective, convergence and postflight.

At launch, OpenAI positions:

- **GPT-6 Luna** as the efficient model for focused, high-volume work;
- **GPT-6 Sol** as the stronger model for complex coding and agentic workflows;
- **GPT-6 Astra** as the most capable model for the hardest end-to-end work.

This does **not** create a required Luna → Sol → Astra staircase. It gives the router overlapping executor options whose best use depends on task geometry, reasoning effort, surface, correction cost and available resources.

The core semantic tiers remain:

`efficient | balanced | strong | frontier`

A named model can span more than one semantic tier. A semantic tier does not require a dedicated named model.

## 2. GPT-6.1 Sol update — 2026-09-29

OpenAI introduced **GPT-6.1 Sol** on 2026-09-29. Current official guidance describes it as delivering capabilities comparable to GPT-6 Astra and as **near-Astra across coding, computer use and professional work**. Astra remains the recommended option for the hardest scientific research.

GPT-6.1 Sol is rolling out in **ChatGPT Work and Codex** and is not an ordinary Chat model. Availability remains plan-, workspace- and rollout-dependent.

For eligible ChatGPT Enterprise token-based billing in Standard mode, the current rate card lists:

| Model | Input | Cached input | Output |
|---|---:|---:|---:|
| GPT-6.1 Sol | $2.00 | $0.10 | $10.00 |
| GPT-6 Astra | $10.00 | $1.00 | $50.00 |

Within that specific billing regime, GPT-6.1 Sol is therefore **5× cheaper on uncached input and output** and **10× cheaper on cached input** than Astra. This ratio is a dated billing fact, not a universal ChatGPT allowance conversion and not proof that every workload consumes exactly one fifth as much plan usage.

### Maximum Token Economy mode — public opt-in profile

`Maximum Token Economy` is an **explicit opt-in routing profile**, not the public default.

Activate it only when the user or governing execution profile clearly asks to minimize model-token cost aggressively while preserving the acceptance boundary. Do not infer this mode merely because a cheaper model exists.

When active and GPT-6.1 Sol is available:

1. keep **Luna** as the first choice for bounded, high-volume work that clears the capability floor;
2. use **GPT-6.1 Sol** as the preferred strong root and as the default substitute for Astra across most non-scientific frontier-shaped work;
3. keep **Astra** behind an exception gate rather than as the routine frontier step;
4. escalate to Astra directly when current evidence indicates a material frontier gap for the task class, when the user explicitly asks for the highest available capability, or when the acceptance risk makes the residual capability difference more important than token economy;
5. after a bounded GPT-6.1 Sol attempt, escalate only for a diagnosed capability shortfall, not for source, authority, tooling, specification or context failure.

The mode changes the **economic preference ordering**, not the semantic tier model:

`Luna for cheap sufficient bulk → GPT-6.1 Sol for strong and most frontier-shaped work → Astra only when the remaining frontier delta is material.`

Outside `Maximum Token Economy`, preserve the ordinary Adaptive Orchestration rules and the Astra adapter's broader plurality of legitimate roles.

## 2A. Official GPT-6 launch facts

As of 2026-09-23 for the original GPT-6 Sol/Luna launch:

- GPT-6 Sol and GPT-6 Luna are available in **ChatGPT Work and Codex** for eligible paid plans, subject to rollout and workspace settings.
- They are **not yet ordinary Chat models**. Chat and Work/Codex model menus are separate surfaces.
- API model IDs are `gpt-6-sol` and `gpt-6-luna`.
- Both API models expose reasoning levels from `none` through `max`; the exact reasoning controls shown in ChatGPT depend on plan, workspace and surface.
- Both expose a **1,050,000-token context window** and **128,000 max output tokens** in the API.
- GPT-6 Sol knowledge cutoff: **2026-04-20**.
- GPT-6 Luna knowledge cutoff: **2026-05-18**.
- Standard short-context API pricing is **$2 input / $10 output per 1M tokens for Sol** and **$0.10 input / $0.50 output for Luna**. Cached reads are priced at 10% of uncached input.
- API prompts above **272K input tokens** use long-context pricing for the full request.
- OpenAI reports improved prompt caching for GPT-6 and says changing reasoning effort or tool availability can preserve earlier cached context.
- OpenAI reports improved alignment versus GPT-5.6 counterparts, including fewer misleading coding-work claims.

These are dated product facts. They do not become permanent routing law.

## 3. Benchmark signal, not benchmark government

Useful launch signals include:

- GPT-6 Sol xhigh: **33.2% on AutomationBench** in OpenAI's reported comparison.
- GPT-6 Sol max: **68.8% on DeepSWE 1.1**.
- GPT-6 Luna max: **66.6% on DeepSWE 1.1**.
- GPT-6 Sol xhigh: **60.5% on OSWorld 2.0 offline**.
- OpenAI reports that Luna at higher effort substantially improves factuality and can match GPT-5.6 Sol on its internal factuality evaluation at much lower API cost.

These results justify a wider Luna capability envelope and a stronger Sol execution role. They do not prove universal superiority, predict one user's Work allowance consumption or authorize routing by benchmark prestige.

## 4. The practical split

### GPT-6 Luna — default bulk executor

Prefer Luna when the task is focused, bounded or repeatable and the main value comes from sustained throughput rather than unusually hard judgment.

Strong Luna-shaped work includes:

- extraction, classification, transformation and synthesis over many items;
- bounded research and document production with clear acceptance criteria;
- repetitive connector/tool workflows;
- routine verification and readback;
- well-specified multi-step execution;
- narrow or moderately complex code changes with a known target;
- high-volume artifact work;
- implementation after a harder architecture decision has already been made.

Luna may use higher reasoning effort when the task is still Luna-shaped but requires more care. Do not treat `Luna` as synonymous with low reasoning.

### GPT-6 Sol — strong executor / co-architect

Prefer Sol when reasoning is load-bearing *inside* execution rather than merely before it.

Strong Sol-shaped work includes:

- complex coding or repo-wide engineering;
- difficult debugging with competing hypotheses;
- agentic workflows with branching state and error recovery;
- architecture that must be invented while implementation proceeds;
- multi-application professional workflows where judgment changes the next action;
- ambiguous source reconciliation with material consequences;
- migrations or refactors where a wrong local choice creates expensive downstream correction;
- high-consequence final review where Luna's result is plausible but not sufficiently trustworthy.

Sol is not automatically the default because a task is important. It is selected when the **irreducible execution geometry** is strong.

## Surface-neutral topology calibration

Under Adaptive Orchestration 6.1, the Sol/Luna pattern is independent from a mandatory Chat return loop. A Sol root in Work or Codex may delegate bounded volume to Luna, converge the result and perform Control-Root Postflight on the same surface when the harness supports it. Chat → Work/Codex → Chat remains valid when the named Adaptive Orchestration Loop Profile is active or the user prefers Chat continuity.

A model change, child spawn and surface transition are separate events. Prefer internal child routing first; preserve the current competent root when possible; request a human-visible surface switch only when the required harness, permission, capability floor or verification path cannot be satisfied internally.

## 5. The overlap zone: balanced is not a missing product

GPT-6 currently has no named Terra model in the released family. Do not manufacture one.

A `balanced` Adaptive Orchestration route can legitimately compile to, for example:

- **Luna + high/max effort** when the task is bounded but cognitively dense;
- **Sol + low/medium effort** when the task benefits from stronger base capability but does not require sustained high reasoning;
- another observed model/effort combination that clears the capability floor more efficiently.

The router chooses a **capability result**, not a product-label symmetry.

## 6. Effort-before-tier, without sacrificial failure

The stable preference remains: if the model is appropriate and the insufficiency is reasoning depth, adjust reasoning effort before escalating the tier.

But this is not a ritual.

Do **not** force Luna to fail first when the task geometry already makes a strong-tier executor the lower-total-work route. Direct Sol routing is justified when:

1. the task is intrinsically complex/agentic rather than merely long;
2. reasoning and execution are tightly coupled;
3. the likely cost of a plausible-but-wrong intermediate result is high;
4. correction would require replaying substantial tool work or repository state;
5. Sol is available and Budget Survivability passes.

The optimization target is **verified useful delta per total work**, not the cheapest first turn.

## 7. Surface law

Model choice does not choose the surface.

### Work

Prefer Work when the sovereign object is connected research, multi-file knowledge production, document/artifact production, browser/computer workflows or sustained connector-mediated execution.

- Luna is the default candidate for bounded high-volume Work.
- Sol becomes the default candidate when the Work trajectory itself requires strong ongoing judgment, branching recovery or co-architecture.
- When Work exposes subagent delegation, prefer Sol-as-root with Luna workers for independent bulk before asking the user to change the whole Work model.

### Codex

Prefer Codex when the sovereign object is a repository, codebase, tests, terminal state, build, runtime, migration or deployment-oriented engineering state.

- Luna is a strong default for well-specified implementation, repetitive fixes, tests and bounded refactors.
- Sol is preferred for difficult debugging, broad refactors, architecture-bearing implementation and complex agentic coding.
- Codex exposes the strongest current control surface for heterogeneous subagents: global child defaults, per-spawn overrides and custom agent files can separate root and child models when the active release exposes those controls.

### Chat

At launch, GPT-6 Sol/Luna are not exposed as ordinary Chat models. Chat remains the controller/postflight surface using the best suitable **Chat-available** model. Never report a GPT-6 Sol/Luna Chat switch unless the product actually exposes it.

## 8. Heterogeneous subagent topology

Current official subagent guidance supports a root/child split rather than requiring every child to inherit the root model.

### Default strong-root pattern

For most demanding Codex work, start with Sol as the root and delegate narrow or high-volume branches to Luna:

```text
Sol root
├─ Luna / high → exploration, search, evidence gathering
├─ Luna / high → tests, logs, repetitive verification
├─ Luna / high → documentation or mechanical implementation
└─ Sol root     → convergence, hard debugging, architecture, final validation
```

This is the preferred default when the root needs strong planning but most child work is bounded.

### Frontier-root pattern

When Astra is justified as the root, do not automatically duplicate Astra across every branch. Prefer:

```text
Astra root
├─ Luna workers → volume, scans, extraction, routine tool work
├─ Sol specialists → ambiguous or architecture-bearing branches
└─ Astra root → decomposition, arbitration, exceptional judgment, final synthesis
```

The Astra adapter owns the frontier-specific geometry. This adapter owns the Luna/Sol child roles.

### Inheritance and override

If no child model or child reasoning effort is configured, current subagent behavior may inherit the parent model and effort. Heterogeneous delegation therefore requires an explicit child policy when cost separation matters.

In current Codex configuration, the `[agents]` block can set `default_subagent_model`, `default_subagent_reasoning_effort` and a concurrency ceiling. Custom agent files can pin their own model and effort. Explicit spawn settings, configured defaults and parent inheritance form a precedence chain; verify the active client's behavior instead of assuming that a configuration was honored.

For ChatGPT Work, prompt for the intended delegation topology and child model/effort when the UI/runtime exposes that capability. Work is hosted and does not expose the same local configuration surface as Codex.

### Fresh-child context preference

When a heterogeneous child only needs a bounded task packet, prefer a fresh or deliberately partial child context rather than cloning the entire parent history. This reduces context duplication and preserves the economic point of using a cheaper worker.

Current Codex Multi-Agent V2 guidance also warns that full-history forks inherit the parent model and reasoning effort and do not accept model/effort overrides. Treat this as dated implementation calibration, not permanent protocol law.

### Fanout law

The point is not “more agents.” The point is **more useful work per expensive root token**.

- use Luna workers for read-heavy, independent and verifiable units;
- promote only failed or genuinely difficult branches to Sol;
- keep parallel write ownership disjoint or serialize mutation;
- cap fanout and depth;
- return summaries/evidence rather than raw intermediate noise;
- compare total work to accepted state, not per-call sticker price.

## 9. Context law

The 1.05M context window is a **capacity ceiling, not a context target**.

Keep Context Diet active:

- send the smallest context that preserves the decision;
- prefer source references and targeted retrieval over dumping entire corpora;
- keep authority and freshness metadata with transported sources;
- preserve reusable stable prefixes when API caching matters;
- split or distill when large context creates distraction or makes correction expensive.

The API's >272K long-context price step is useful evidence that very large prompts have real economics, but it is **API pricing**, not a Work/Codex allowance formula.

## 10. Economics boundary

### 10.1 Standard short-context API price vector

For the dated 2026-09-23 calibration, use the official **Standard / short-context** text-token rates per 1M tokens:

| Model | Input | Output |
|---|---:|---:|
| GPT-6 Luna | $0.10 | $0.50 |
| GPT-5.6 Luna | $0.20 | $1.20 |
| GPT-6 Sol | $2.00 | $10.00 |
| GPT-5.6 Sol | $4.00 | $20.00 |
| GPT-6 Astra | $10.00 | $50.00 |

Long-context, Batch, Flex, Fast, regional-processing and tool-call prices are separate regimes and must be recalculated from current official pricing rather than inferred from this table.

### 10.2 Mixed-workload cost equation

Let:

- `I` = uncached input tokens in millions;
- `O` = output tokens in millions;
- `pᵢ(m)` = standard short-context input price of model `m`;
- `pₒ(m)` = standard short-context output price of model `m`.

Then the text-token API cost proxy is:

`C(m; I, O) = pᵢ(m)·I + pₒ(m)·O`

This proxy intentionally excludes cached-input effects, cache writes, tools, regional uplifts and non-Standard service tiers unless those terms are explicitly added.

For two models `A` and `B`, define:

`R(A:B | I,O) = C(A;I,O) / C(B;I,O)`

If `R = 20`, model A costs 20× model B for that workload. The savings from moving from A to B are:

`Savings(A→B) = 1 - C(B;I,O)/C(A;I,O)`

### 10.3 Constant-ratio relations

Some pairs have proportional input/output prices, so their ratio is independent of the input/output mix:

- `R(GPT-6 Sol : GPT-6 Luna) = 20×`
- `R(GPT-6 Astra : GPT-6 Sol) = 5×`
- `R(GPT-6 Astra : GPT-6 Luna) = 100×`
- `R(GPT-5.6 Sol : GPT-6 Luna) = 40×`
- `R(GPT-6 Astra : GPT-5.6 Sol) = 2.5×`
- `R(GPT-5.6 Sol : GPT-6 Sol) = 2×`

Equivalent savings readings:

- GPT-6 Luna is **95% cheaper** than GPT-6 Sol;
- GPT-6 Sol is **80% cheaper** than GPT-6 Astra;
- GPT-6 Luna is **99% cheaper** than GPT-6 Astra;
- GPT-6 Luna is **97.5% cheaper** than GPT-5.6 Sol;
- GPT-6 Sol is **50% cheaper** than GPT-5.6 Sol.

### 10.4 Generation-over-generation Luna equation

GPT-5.6 Luna → GPT-6 Luna is not perfectly proportional because output fell more than input:

`R(6 Luna : 5.6 Luna | I,O) = (0.10I + 0.50O) / (0.20I + 1.20O)`

Therefore:

- input-only: GPT-6 Luna costs **50%** of GPT-5.6 Luna → **50% cheaper**;
- output-only: GPT-6 Luna costs **41.67%** of GPT-5.6 Luna → **58.33% cheaper**;
- any mixed workload falls between those endpoints.

By contrast:

`R(6 Sol : 5.6 Sol) = 0.5`

so GPT-6 Sol is exactly **50% cheaper** than GPT-5.6 Sol for any uncached text-token input/output mix under this price regime.

### 10.5 Cross-generation ratios that depend on workload mix

For GPT-6 Sol versus GPT-5.6 Luna:

`R(6 Sol : 5.6 Luna | I,O) = (2I + 10O) / (0.20I + 1.20O)`

This ranges from **10×** for input-only work to **8.33×** for output-only work.

For GPT-6 Astra versus GPT-5.6 Luna:

`R(6 Astra : 5.6 Luna | I,O) = (10I + 50O) / (0.20I + 1.20O)`

This ranges from **50×** for input-only work to **41.67×** for output-only work.

For GPT-5.6 Sol versus GPT-5.6 Luna:

`R(5.6 Sol : 5.6 Luna | I,O) = (4I + 20O) / (0.20I + 1.20O)`

This ranges from **20×** for input-only work to **16.67×** for output-only work.

### 10.6 Luna-normalized price index

Using GPT-6 Luna as `1.0`:

| Model | Input-price index | Output-price index |
|---|---:|---:|
| GPT-6 Luna | 1× | 1× |
| GPT-5.6 Luna | 2× | 2.4× |
| GPT-6 Sol | 20× | 20× |
| GPT-5.6 Sol | 40× | 40× |
| GPT-6 Astra | 100× | 100× |

This makes the current economic geometry explicit:

`GPT-6 Luna = 1 → GPT-6 Sol = 20 → GPT-6 Astra = 100`

with GPT-5.6 Luna and Sol sitting at `2/2.4` and `40` respectively.

### 10.7 Routing interpretation

The large price gap does **not** create a compulsory routing staircase.

Use the equations to estimate **API cost pressure**, then combine them with capability floor, correction/retry cost and task geometry:

- prefer Luna for bulk where it clears the floor;
- prefer Sol when stronger reasoning inside execution is expected to reduce replay, correction or failure enough to justify the premium;
- use Astra only under the canonical frontier gate and its own adapter when available;
- do not force Luna to fail merely because it is cheaper;
- do not promote to Sol or Astra merely because the task is important.

The optimization target is not minimum first-turn cost:

`Preferred route = argmin(expected total cost to verified acceptance)`

where expected total cost includes the probability-weighted cost of retries, correction, repeated tool work, context reconstruction and higher-tier bursts when material.

### 10.8 ChatGPT allowance firewall

These equations are **API price equations only**.

They must **not** be copied into ChatGPT Work/Codex allowance math. ChatGPT usage can depend on model, task, reasoning effort, tool work, plan and workspace policy. Unless the product exposes a reliable run-level conversion, never infer rules such as:

- `1 Sol Work run = 20 Luna Work runs`;
- `1 Astra run = 5 Sol runs`;
- allowance percentage consumed = API token-cost ratio.

The token-price ratios can inform qualitative economic intuition; they cannot manufacture product telemetry.

## 11. Default routing matrix

| Workload geometry | Preferred starting route | Escalate when |
|---|---|---|
| Focused extraction / classification / transformation | Luna · low/medium, or Luna workers under a stronger root | reasoning, not source/tool failure, remains insufficient |
| Bounded multi-step artifact work | Luna · medium/high | ambiguity or correction cost becomes load-bearing |
| Dense but bounded judgment with clear inputs | Luna · high/max or Sol · low/medium | choose by total-work efficiency |
| Narrow code patch / tests / mechanical refactor | Codex + Luna · medium/high | debugging/architecture becomes genuinely hard |
| Complex repo-wide engineering / hard debugging | Codex + Sol root · medium/high, Luna workers for bounded branches | irreducible frontier judgment remains |
| Long connector/computer workflow with stable decisions | Work + Luna · medium/high | trajectory branches require repeated strong judgment |
| Multi-app agentic workflow with uncertain recovery | Work + Sol root, Luna workers when independent bulk exists | frontier cognition materially changes outcome |
| High-consequence review / architecture | Sol · xhigh/max | Astra burst/full route passes canonical frontier gate |

Reasoning labels are recommendations only when the current surface actually exposes them.

## 12. Failure and re-entry

When Luna underperforms:

1. classify the failure;
2. repair source, authority, tool, context or specification failures first;
3. if the failure is cognitive and Luna is still the right executor geometry, raise effort when available;
4. if a named irreducible reasoning delta remains, route that delta or the execution to Sol;
5. return to the lowest sufficient tier after the hard delta is resolved.

When Sol underperforms:

- do not automatically expand context or autonomy;
- isolate the remaining hard delta;
- use Astra only if available, justified by the frontier gate and permitted by the active Astra adapter/user profile;
- preserve tests, receipts and Control-Root Postflight.

## 13. Locality and migration note

This adapter describes the GPT-6 family **as observed at the dated release state**. Future Chat availability, changed usage pools, new family members, repricing or changed effort controls can alter the calibration without changing the canonical Adaptive Orchestration architecture.

A future model release should update or supersede this adapter rather than spraying model names through the stable core.

## 14. Official sources

- OpenAI — Introducing GPT-6 Sol and Luna: https://openai.com/index/introducing-gpt-6-sol-and-luna/
- OpenAI API — GPT-6 Sol: https://developers.openai.com/api/docs/models/gpt-6-sol
- OpenAI API — GPT-6 Luna: https://developers.openai.com/api/docs/models/gpt-6-luna
- OpenAI API — GPT-6 model guidance: https://developers.openai.com/api/docs/guides/latest-model
- OpenAI API — Pricing: https://developers.openai.com/api/docs/pricing
- OpenAI Help — ChatGPT Release Notes: https://help.openai.com/en/articles/6825453-chatgpt-release-notes
- OpenAI — Subagents: https://learn.chatgpt.com/docs/agent-configuration/subagents
- OpenAI Codex source — current `[agents]` configuration fields: https://github.com/openai/codex/blob/main/codex-rs/config/src/config_toml.rs

## Final law

> **Luna buys throughput; Sol buys stronger judgment inside execution. Keep Sol at the bottleneck, delegate bounded bulk to Luna when the harness can do so, and promote only the difficult branch. Never turn API price ratios into imaginary Work allowance mathematics. The sovereign object chooses the surface; the delegation topology chooses where each unit of cognition is spent.**

<!-- MOON-SOURCE-PUBLIC-STAMP -->

---

> 🌙 **Moon Source** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Source/blob/main/LICENSING.md) · [Use & attribution](https://github.com/luahelenammc/Moon-Source/blob/main/MOON_SOURCE_USE_AND_ATTRIBUTION.md) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Source/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
